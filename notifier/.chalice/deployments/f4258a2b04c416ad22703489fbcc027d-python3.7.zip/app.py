import os
import requests
from chalice import Chalice

app = Chalice(app_name='notifier')


@app.on_sns_message(topic='notifier')
def index(event):
    app.log.debug("Received message with subject: %s, message: %s",
                  event.subject, event.message)
    requests.post(
        os.environ["MAILGUN_URL"],
        auth=("api", os.environ["MAILGUN_API_KEY"]),
        data={"from": "Donato Perconti <donato.perconti@gmail.com>",
              "to": ["autumlucille@gmail.com"],
              "subject": "Hello",
              "text": "Testing some Mailgun awesomness!"})
