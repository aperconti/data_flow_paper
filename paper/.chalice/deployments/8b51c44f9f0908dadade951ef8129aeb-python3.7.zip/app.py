import os
import boto3
from chalice import Chalice
import ast
import json

app = Chalice(app_name='paper')
_PAPER_DB = None

_NOTIFIER_TOPIC = None


def get_notifier_topic():
    global _NOTIFIER_TOPIC
    if _NOTIFIER_TOPIC is None:
        _NOTIFIER_TOPIC = boto3.client('sns')
    return _NOTIFIER_TOPIC


def get_paper_db():
    global _PAPER_DB
    if _PAPER_DB is None:
        _PAPER_DB = boto3.resource('dynamodb').Table(
            os.environ['PAPER_TABLE_NAME'])
    return _PAPER_DB


def publish_to_sns(body):
    response = get_notifier_topic().publish(
        TargetArn=os.environ["NOTIFIER_ARN"],
        Message=json.dumps({'default': json.dumps(body)}),
        MessageStructure='json'
    )
    app.log.debug("publishing to SNS topic: %s response: %s", body, response)


@app.route('/paper', methods=['POST'])
def create_paper():
    body = ast.literal_eval(app.current_request.raw_body.decode())
    table = get_paper_db()
    response = table.put_item(
        Item=body
    )
    publish_to_sns(body)
    return response


@app.route('/paper', methods=['PATCH'])
def update_paper():
    body = ast.literal_eval(app.current_request.raw_body.decode())
    table = get_paper_db()
    try:
        response = table.update_item(
            Key={
                'id': body.get('id')
            },
            UpdateExpression="set info.teacher_email=:r, info.status=:p",
            ExpressionAttributeValues={
                ':r': body.get('teacher_email'),
                ':p': 'assigned'
            },
            ReturnValues="UPDATED_NEW"
        )
    except:
        app.log.error("Error updating: %s body: %s",
                      body.get('id'), body)
        return
    body['status'] = 'assigned'
    publish_to_sns(body)
    return response
